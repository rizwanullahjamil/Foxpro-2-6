/*
**
*
* MENU.C - Sample API using menu functions.
*
* Copyright (c) 1991, Fox Holdings, Inc.
* Fox Software System's Group
* 134 W. South Boundary
* Perrysburg, Ohio  43551
*
* Description: On load places a new pad "Display" on the system menu
*   bar with items to switch between 25 and 50 row display.
*
**
*/
#include <pro_ext.h>

MENUID SysMenuId;
MENUID PopupId;
ITEMID PadId;

void FAR SetDispVGA50()
{
    _Execute("SET DISP TO VGA50");
}

void FAR SetDispVGA25()
{
    _Execute("SET DISP TO VGA25");
}

void FAR StartUp()
{
        ITEMID Bar1_Id;
        ITEMID Bar2_Id;

        int Error;
/*
    Add new pad to SYSMENU.
*/
    SysMenuId = _MenuId(_SYSMENU);
    PadId = _GetNewItemId(SysMenuId);

    if (_NewItem(SysMenuId, PadId, _LASTITEM, "Displa\\<y"))
    {
        _Error(623); /* "Menu item cannot be defined." */
    }
/*
    Define popup menu.
*/
    PopupId = _GetNewMenuId();

    if (Error = _NewMenu(MPOPUP, PopupId))
    {
        _Error(-Error);
    }
    Bar1_Id = _GetNewItemId(PopupId);
/*
        WARNING: Call _NewItem() before another _GetNewItemId().
*/
    if (_NewItem(PopupId, Bar1_Id, _LASTITEM, "VGA \\<50"))
    {
        _Error(623); /* "Menu item cannot be defined." */
    }
    Bar2_Id = _GetNewItemId(PopupId);

    if (_NewItem(PopupId, Bar2_Id, _LASTITEM, "VGA \\<25"))
    {
        _Error(623); /* "Menu item cannot be defined." */
    }
/*
    Attach popup to pad.
*/
    _SetItemSubMenu(SysMenuId, PadId, PopupId);
/*
    Set up keyboard shortcuts.
*/
    _SetItemCmdKey(SysMenuId, PadId, 0x4100 |  21, "");
    _SetItemCmdKey(PopupId, Bar1_Id, 0x4100 | 124, "Alt+5");
    _SetItemCmdKey(PopupId, Bar2_Id, 0x4100 | 121, "Alt+2");
/*
    Set up selection action.
*/
    _OnSelection(PopupId, Bar1_Id, SetDispVGA50);
    _OnSelection(PopupId, Bar2_Id, SetDispVGA25);
}

void FAR ShutDown()
{
    _DisposeItem(SysMenuId, PadId);
    _DisposeMenu(PopupId);
}

FoxInfo myFoxInfo[] =
{
    {"STARTUP",     StartUp,    CALLONLOAD,   ""},
    {"SHUTDOWN",    ShutDown,   CALLONUNLOAD, ""},
};

FoxTable _FoxTable =
{
    (FoxTable FAR *)0, sizeof(myFoxInfo) / sizeof(FoxInfo), myFoxInfo
};